d/\(OFF\).sh; exit              <
rm: /data/media/legacy/*: Permission denied
rm: /cache/magisk.log.bak: Permission denied
rm: /cache/magisk.log: Permission denied
rm: /data/tombstones/*: Permission denied
rm: /data/system/dropbox/*: Permission denied
rm: /data/system/usagestats/*: Permission denied
rm: /data/media/0/.*: Permission denied
rm: /data/media/0/MT2: Permission denied
rm: /data/media/0/MIUI: Permission denied
rm: /data/media/0/tencent: Permission denied
touch: '/data/media/0/tencent': Permission denied
rm: /data/media/0/MidasOversea: Permission denied
touch: '/data/media/0/MidasOversea': Permission denied
rm: /data/media/0/.backups: Permission denied
touch: '/data/media/0/.backups': Permission denied
rm: /data/media/0/QTAudioEngine: Permission denied
mkdir: '/data/media/0/QTAudioEngine': Permission denied
rm: /data/media/0/.UTSystemConfig: Permission denied
rm: /data/media/0/.DataStorage: Permission denied
rm: /data/media/0/Android/obj: Permission denied
rm: /data/media/0/Android/data/.um: Permission denied
touch: '/data/media/0/Android/data/.um': Permission denied
rm: /data/media/0/By@N1B7R: Permission denied
mkdir: '/data/media/0/By@N1B7R': Permission denied
rm: /data/media/0/@ABO_B7R1: Permission denied
mkdir: '/data/media/0/@ABO_B7R1': Permission denied
rm: /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini: Permission denied
rm: /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/AntiCheat.ini: Permission denied
chmod: /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini: Permission denied
chmod: /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks: Permission denied
chmod: /data/data/com.vng.pubgmobile/lib/*: No such file or directory
Another app is currently holding the xtables lock. Perhaps you want to use the -w option?
rm: /data/media/0/CryizErBackup: Permission denied
rm: /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini: Permission denied
Another app is currently holding the xtables lock. Perhaps you want to use the -w option?
Another app is currently holding the xtables lock. Perhaps you want to use the -w option?
Another app is currently holding the xtables lock. Perhaps you want to use the -w option?
Another app is currently holding the xtables lock. Perhaps you want to use the -w option?
Another app is currently holding the xtables lock. Perhaps you want to use the -w option?
Another app is currently holding the xtables lock. Perhaps you want to use the -w option?
Another app is currently holding the xtables lock. Perhaps you want to use the -w option?
Another app is currently holding the xtables lock. Perhaps you want to use the -w option?
Another app is currently holding the xtables lock. Perhaps you want to use the -w option?
Another app is currently holding the xtables lock. Perhaps you want to use the -w option?
Another app is currently holding the xtables lock. Perhaps you want to use the -w option?
Another app is currently holding the xtables lock. Perhaps you want to use the -w option?