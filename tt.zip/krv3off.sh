am force-stop com.pubg.krmobile
iptables -F
iptables -F
iptables --flush
iptables --flush
iptables -P INPUT ACCEPT
iptables -P FORWARD ACCEPT
iptables -P OUTPUT ACCEPT
iptables -F
iptables -t nat -F
iptables -t mangle -F
iptables -X
iptables --flush
iptables -F
iptables --flush
iptables -F
iptables -X
echo '128' > /proc/sys/fs/inotify/max_user_instances 
echo '8192' > /proc/sys/fs/inotify/max_user_watches 
echo '16384' > /proc/sys/fs/inotify/max_queued_events
cd /proc/sys/fs/inotify && echo "16384" > max_queued_events
cd /proc/sys/fs/inotify && echo "128" > max_user_instances
cd /proc/sys/fs/inotify && echo "8192" > max_user_watches

chmod 777 /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs0,PufferEifs1} &>/dev/null
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini &>/dev/null
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
rm -rf /data/data/com.pubg.krmobile/*
rm -rf /data/data/com.pubg.krmobile/files
rm -rf /data/data/com.pubg.krmobile/app_appcache
rm -rf /data/data/com.pubg.krmobile/cache
rm -rf /data/data/com.pubg.krmobile/app_bugly
rm -rf /data/data/com.pubg.krmobile/no_backup
rm -rf /data/data/com.pubg.krmobile/shared_prefs
rm -rf /data/data/com.pubg.krmobile/app_webview
rm -rf /data/data/com.pubg.krmobile/cache
rm -rf /data/data/com.pubg.krmobile/app_textures
rm -rf /data/data/com.pubg.krmobile/databases
rm -rf /data/data/com.pubg.krmobile/app_crashrecord
rm -rf /data/data/com.pubg.krmobile/code_cache
rm -rf /data/data/com.pubg.krmobile/app_databases
rm -rf /data/data/com.pubg.krmobile/app_webview_imsdk_inner_webview
rm -rf /data/data/com.pubg.krmobile/files/app
rm -rf /data/data/com.pubg.krmobile/files/data
rm -rf /data/data/com.pubg.krmobile/files/hawk_data_init
rm -rf /data/data/com.pubg.krmobile/files/iMSDK
rm -rf /data/data/com.pubg.krmobile/files/local_crash_lock
rm -rf /data/data/com.pubg.krmobile/files/TAPM_CM_AUDIT
rm -rf /data/media/0/MidasOversea
rm -rf /data/media/0/tencent
rm -rf /data/media/0/MIUI
rm -rf /data/media/0/MT2
rm -rf /data/media/0/QTAudioEngine
rm -rf /data/media/0/.backups/com.pubg.krmobile/helpshift/database
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Match
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/login-identifier.txt
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/StatEventReportedFlag
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
rm -rf /data/media/0/.backups
rm -rf /data/media/0/Tencent
rm -rf /data/media/0/Android/data/com.pubg.krmobile/cache
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/tbslog
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15339.pak
pm install -r /data/app/com.pubg.krmobile*/base.apk
chmod 777 /data/media/0/Android/data/com.pubg.krmobile
chmod 777 /data/media/0/Android/data/com.pubg.krmobile/*
chmod 777 /data/media/0/Android/data/com.pubg.krmobile/*/*
chmod 777 /data/media/0/Android/data/com.pubg.krmobile/*/*/*
chmod 777 /data/media/0/Android/data/com.pubg.krmobile/*/*/*/*
chmod 777 /data/media/0/Android/data/com.pubg.krmobile/*/*/*/*/*
chmod 777 /data/media/0/Android/data/com.pubg.krmobile/*/*/*/*/*/*
chmod 777 /data/media/0/Android/data/com.pubg.krmobile/*/*/*/*/*/*/*
chmod -R 755 /data/data/com.pubg.krmobile/lib/*
am kill com.pubg.krmobile
am force-stop com.pubg.krmobile
pm install -r /data/app/com.pubg.krmobile*/base.apk
chmod -R 755 /data/data/com.pubg.krmobile/lib/*
pm install -r /data/app/com.pubg.krmobile*/base.apk
chmod -R 755 /data/data/com.pubg.krmobile/lib/*