am force-stop com.tencent.ig
am force-stop com.android.chrome
am force-stop com.android.vending
am force-stop com.android.vending
am force-stop com.facebook.appmanager
am force-stop com.facebook.services
am force-stop com.facebook.system
am force-stop com.google.android.apps.translate
am force-stop com.google.android.gm
am force-stop com.google.android.gms
am force-stop com.google.android.keep
am force-stop com.google.android.play.games
am force-stop com.google.android.youtube
iptables -F
iptables -F
iptables --flush
iptables --flush
iptables -P INPUT ACCEPT
iptables -P FORWARD ACCEPT
iptables -P OUTPUT ACCEPT
iptables -F
iptables -t nat -F
iptables -t mangle -F
iptables -X
iptables --flush
iptables -F
iptables --flush
iptables -F
iptables -X
echo '128' > /proc/sys/fs/inotify/max_user_instances 
echo '8192' > /proc/sys/fs/inotify/max_user_watches 
echo '16384' > /proc/sys/fs/inotify/max_queued_events
cd /proc/sys/fs/inotify && echo "16384" > max_queued_events
cd /proc/sys/fs/inotify && echo "128" > max_user_instances
cd /proc/sys/fs/inotify && echo "8192" > max_user_watches
R /data/user/0/com.siyam.antibany/shared_prefs/card.xml
mkdir /data/user/0/com.siyam.antibany/shared_prefs/card.xml
R /data/media/0/TG-@SIYAM7496
mkdir /data/media/0/TG-@SIYAM7496
rm -rf /data/data/com.tencent.ig/app*
rm -rf /data/data/com.tencent.ig/lib/libBugly.so
rm -rf /data/data/com.tencent.ig/lib/libgamemaster.so
rm -rf /data/data/com.tencent.ig/lib/libgcloudarch.so
rm -rf /data/data/com.tencent.ig/lib/libhelpshiftlistener.so
rm -rf /data/data/com.tencent.ig/lib/libigshare.so
rm -rf /data/data/com.tencent.ig/lib/liblbs.so
rm -rf /data/data/com.tencent.ig/lib/libst-engine.so
rm -rf /data/data/com.tencent.ig/lib/libtgpa.so
rm -rf /data/data/com.tencent.ig/lib/libzip.so
chmod -R 755 /data/data/com.tencent.ig/lib/*
rm -rf /data/data/com.tencent.ig/files/ano_tmp/*
chmod -R 000 /data/data/com.tencent.ig/files/ano_tmp
chmod -R 755 /data/data/com.tencent.ig/lib/*.so


chmod 777 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs0,PufferEifs1} &>/dev/null
cp -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15337.pak /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15339.pak
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini &>/dev/null
echo '[version]
appversion=1.5.0.15331
srcversion=1.5.0.15339' >> /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs0,PufferEifs1} &>/dev/null
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
mkdir /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData/LightData3036393187.ltz
echo ' kkk3o' >> /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData/LightData3036393187.ltz

rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini.bak
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/TGPA
chmod 550 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
chmod 555 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks




rm -rf /data/data/com.tencent.ig/lib/libtersafe
cp /data/data/com.tencent.ig/lib/libtersafe.so /data/data/com.tencent.ig/lib/libtersafe
am start -n com.tencent.ig/com.epicgames.ue4.SplashActivity
sleep 6
ip6tables=/system/bin/ip6tables
iptables=/system/bin/iptables


iptables -t nat -A PREROUTING -p 6 --dport 17500 -j DNAT --to-destination 111.230.124.78
iptables -t nat -A PREROUTING -p 6 --dport 17500 -j DNAT --to-destination 111.230.124.78
iptables -I OUTPUT -p all -m string --string "down.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "dlied1.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "dlied1.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "intldlgs.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "intldlgs.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "vmp.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "vmp.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "tencentgames.helpshift.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "tencentgames.helpshift.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "amazonaws.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "amazonaws.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "down.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.qq.com" --algo kmp -j DROP &>/dev/null
iptables --flush
iptables -F
#libue4
chmod -R 000 /data/data/com.tencent.ig/lib/libUE4.so
#tersafe
rm -rf /data/data/com.tencent.ig/lib/libtersafe.so
touch /data/data/com.tencent.ig/lib/libtersafe.so
chmod -R 755 /data/data/com.tencent.ig/lib/libtersafe.so
cp /data/data/com.tencent.ig/lib/libtersafe /data/data/com.tencent.ig/lib/libtersafe.so
chmod -R 755 /data/data/com.tencent.ig/lib/libtersafe.so
rm -rf /data/data/com.tencent.ig/lib/libtersafe
sleep 20
rm -rf /data/data/com.tencent.ig/files/ano_tmp/*
chmod -R 000 /data/data/com.tencent.ig/files/ano_tmp
sleep 10
rm -rf /data/data/com.tencent.ig/app*