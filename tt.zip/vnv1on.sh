alias R="rm -rf"
alias E="echo"
alias S="sleep"
alias SP="chmod"


pm path com.vng.pubgmobile &> /dev/null
killall com.vng.pubgmobile 2&> /dev/null
DUMP() {
  pm dump $1 | grep $2 | tr ' ' '\n' | grep $1 | sed s/$2// | tr -d '\n';
};
lib=`ls -mR $(DUMP com.vng.pubgmobile legacyNativeLibraryDir=) | grep : | tr -d : | grep /arm | grep -v sosna`

SAVE(){
cp $lib/$1 $lib/$1.bak
}
RETURN(){
mv $lib/$1.bak $lib/$1
}

SP -R 755 /data/data/com.vng.pubgmobile/lib/*
R /data/data/com.vng.pubgmobile/databases
SP 755 /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
touch /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15338.pak
cp -rf /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15338.pak /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.26868.pak
R /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini &>/dev/null
E '[version]
appversion=1.5.0.15331
srcversion=1.5.0.26868' >> /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
R /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs0,PufferEifs1} &>/dev/null
SP 550 /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
SP 555 /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
R /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
mkdir /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
E " null " >> /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz
cp /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
R /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz
R /data/cache/magisk.log
R /data/cache/magisk.log.bak
SP 755 /data/data/com.vng.pubgmobile/lib/*
R /sdcard/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/ImageDownload
R /sdcard/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
R /sdcard/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
R /sdcard/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
R /sdcard/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/TableDatas
R /sdcard/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
R /sdcard/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/GameErrorNoRecords
R /sdcard/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/StatEventReportedFlag
R /sdcard/Android/data/com.vng.pubgmobile/files/TGPA
R /sdcard/Android/data/com.vng.pubgmobile/cache
R /sdcard/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
R /sdcard/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
R /data/user/0/com.siyam.antibany/shared_prefs/card.xml
mkdir /data/user/0/com.siyam.antibany/shared_prefs/card.xml
R /data/media/0/TG-@SIYAM7496
mkdir /data/media/0/TG-@SIYAM7496
SP -R 755 /data/data/com.vng.pubgmobile/lib/*
R $lib/{libzip.so,libBugly.so,libgamemaster.so,libgcloudarch.so,libhelpshiftlistener.so,libigshare.so,liblbs.so-libnpps-jni.so,libst-engine.so,libtgpa.so}
SP -R 755 /data/data/com.vng.pubgmobile/lib/*
SAVE libtprt.so
SAVE libUE4.so
E 
E -ne '                   \033[1;37m  □□□□□□□□□□0% \r'
S 0.1
E -ne '                   \033[1;31m  ■□□□□□□□□□10% \r'
S 0.1
E -ne '                   \033[1;31m  ■■□□□□□□□□20% \r'
S 0.1
E -ne '                   \033[1;33m  ■■■□□□□□□□30% \r'
S 0.1
E -ne '                   \033[1;33m  ■■■■□□□□□□40% \r'
S 0.1
E -ne '                   \033[1;33m  ■■■■■□□□□□50% \r'
S 0.1
E -ne '                   \033[1;36m  ■■■■■■□□□□60% \r'
S 0.1
E -ne '                   \033[1;36m  ■■■■■■■□□□70% \r'
S 0.1
E -ne '                   \033[1;36m  ■■■■■■■■□□80% \r'
S 0.1
E -ne '                   \033[1;32m  ■■■■■■■■■□90% \r'
S 0.1
E -ne '                   \033[1;32m  ■■■■■■■■■■100% \r'
S 0.1
E -ne '                   \033[1;32m  Process Done✓ \r'
S 0.1
E -ne ' \n'
E "                   \033[0m"
am start -n com.vng.pubgmobile/com.epicgames.ue4.SplashActivity > /dev/null
S 3.5
ip6tables=/system/bin/ip6tables
iptables=/system/bin/iptables

uptime
#====================================
iptables -I OUTPUT -p all -m string --string "down.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "dlied1.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "dlied1.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "asia.csoversea.mbgame.anticheatexpert.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "cs.mbgame.gamesafe.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "intldlgs.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "intldlgs.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "vmp.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "vmp.qq.com" --algo kmp -j DROP &>/dev/null
iptables -I OUTPUT -p all -m string --string "down.qq.com" --algo bm -j DROP &>/dev/null
iptables -I INPUT -p all -m string --string "down.qq.com" --algo kmp -j DROP &>/dev/null
iptables --flush
iptables -F
S 7
R $lib/{libUE4.so,libtprt.so}
S 3
RETURN libtprt.so
RETURN libUE4.so
SP 755 /data/data/com.vng.pubgmobile/lib/*
SP 550 /data/data/com.vng.pubgmobile/files
R /data/data/com.vng.pubgmobile/files/*
S 0.5
touch /data/data/com.vng.pubgmobile/files/ano_tmp
SP 000 /data/data/com.vng.pubgmobile/files/ano_tmp
SP 550 /data/data/com.vng.pubgmobile/files
R /data/data/com.vng.pubgmobile/app_crashrecord
touch /data/data/com.vng.pubgmobile/app_crashrecord
S 1
R /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Config/Android/Updater.ini