rm -rf /data/media/legacy/*
rm -rf /data/data/com.pubg.krmobile/cache/*
rm -rf /data/data/com.pubg.krmobile/app*
rm -rf /cache/magisk.log.bak 
rm -rf /cache/magisk.log 
rm -rf /data/log/* 
rm -rf /data/tombstones/* 
rm -rf /data/system/dropbox/* 
rm -rf /data/system/usagestats/*
rm -rf /data/media/0/.*
rm -rf /data/media/0/MT2
rm -rf /data/media/0/MIUI
rm -rf /data/media/0/tencent
touch /data/media/0/tencent
rm -rf /data/media/0/MidasOversea
touch /data/media/0/MidasOversea
rm -rf /data/media/0/.backups
touch /data/media/0/.backups
rm -rf /data/media/0/QTAudioEngine
mkdir /data/media/0/QTAudioEngine
rm -rf /data/media/0/.UTSystemConfig
rm -rf /data/media/0/.DataStorage
rm -rf /data/media/0/Android/obj
rm -rf /data/media/0/Android/data/.um
touch /data/media/0/Android/data/.um
R /data/user/0/com.siyam.antibany/shared_prefs/card.xml
mkdir /data/user/0/com.siyam.antibany/shared_prefs/card.xml
R /data/media/0/TG-@SIYAM7496
mkdir /data/media/0/TG-@SIYAM7496

SK="/data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini"
rm -rf $SK
echo "[/Script/Client.GDolphinUpdater]\nDisable=true" > $SK

rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/AntiCheat.ini
echo "[UserAntiCheat]
Disable=true" > /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/AntiCheat.ini
chmod 555 /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/AntiCheat.ini

chmod 777 /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs0,PufferEifs1} &>/dev/null
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15339.pak /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.59494.pak
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini &>/dev/null
echo '[version]
appversion=1.5.0.15331
srcversion=1.5.0.25559' >> /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{PufferEifs0,PufferEifs1} &>/dev/null
chmod 550 /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
chmod 555 /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
mkdir /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
echo "  

" >> /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz
cp /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.15339.pak /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_1.5.0.25559.pak
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/LightData3036393187.ltz
rm -rf /data/data/com.pubg.krmobile/databases
mkdir /data/media/0/SIAM
cp /data/data/com.pubg.krmobile/lib/* /data/media/0/SIAM
rm -rf /data/data/com.pubg.krmobile/lib/libBugly.so
rm -rf /data/data/com.pubg.krmobile/lib/libgamemaster.so
rm -rf /data/data/com.pubg.krmobile/lib/libgcloudarch.so
rm -rf /data/data/com.pubg.krmobile/lib/libhelpshiftlistener.so
rm -rf /data/data/com.pubg.krmobile/lib/libigshare.so
rm -rf /data/data/com.pubg.krmobile/lib/liblbs.so
rm -rf /data/data/com.pubg.krmobile/lib/libst-engine.so
rm -rf /data/data/com.pubg.krmobile/lib/libzip.so
chmod -R 755 /data/data/com.pubg.krmobile/files
rm -rf /data/data/com.pubg.krmobile/files/ano_tmp/*

iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 0000 -j DROP
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 17500 -j DROP
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 15292 -j DROP
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 443 -j DROP
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 20371 -j DROP
iptables -I OUTPUT -m owner --uid-owner $(awk '/^com.pubg.krmobile/ {print $2}' /data/system/packages.list) -p tcp ! --dport 18081 -j DROP

iptables -I INPUT -p tcp -s astat.bugly.qcloud.com -j ACCEPT
iptables -I OUTPUT -p tcp -d astat.bugly.qcloud.com  -j ACCEPT
iptables -I INPUT -p tcp -s cloud.gsdk.proximabeta.com -j ACCEPT
iptables -I OUTPUT -p tcp -d cloud.gsdk.proximabeta.com  -j ACCEPT
iptables -I INPUT -p tcp -s down.anticheatexpert.com -j ACCEPT
iptables -I OUTPUT -p tcp -d down.anticheatexpert.com  -j ACCEPT
iptables -I INPUT -p tcp -s astat.bugly.qcloud.com -j ACCEPT
iptables -I OUTPUT -p tcp -d astat.bugly.qcloud.com  -j ACCEPT
iptables -I INPUT -p tcp -s cloud.gsdk.proximabeta.com -j ACCEPT
iptables -I OUTPUT -p tcp -d cloud.gsdk.proximabeta.com  -j ACCEPT
iptables -I INPUT -p tcp -s down.anticheatexpert.com -j ACCEPT
iptables -I OUTPUT -p tcp -d down.anticheatexpert.com  -j ACCEPT

am start -a android.intent.action.MAIN -n com.pubg.krmobile/com.epicgames.ue4.SplashActivity
sleep 7

rm -rf /data/data/com.pubg.krmobile/lib/libUE4.so
rm -rf /data/data/com.pubg.krmobile/lib/libtprt.so
rm -rf /data/data/com.pubg.krmobile/lib/libtersafe.so
cp /data/media/0/SIAM/libUE4.so /data/data/com.pubg.krmobile/lib
cp /data/media/0/SIAM/libtprt.so /data/data/com.pubg.krmobile/lib
cp /data/media/0/SIAM/libtersafe.so /data/data/com.pubg.krmobile/lib
cp /data/media/0/SIAM/libBugly.so /data/data/com.pubg.krmobile/lib
cp /data/media/0/SIAM/libgamemaster.so /data/data/com.pubg.krmobile/lib
cp /data/media/0/SIAM/libgcloudarch.so /data/data/com.pubg.krmobile/lib
cp /data/media/0/SIAM/libhelpshiftlistener.so /data/data/com.pubg.krmobile/lib
cp /data/media/0/SIAM/libigshare.so /data/data/com.pubg.krmobile/lib
cp /data/media/0/SIAM/liblbs.so /data/data/com.pubg.krmobile/lib
cp /data/media/0/SIAM/libst-engine.so /data/data/com.pubg.krmobile/lib
cp /data/media/0/SIAM/libzip.so /data/data/com.pubg.krmobile/lib
chmod 755 /data/data/com.pubg.krmobile/lib/*
sleep 10
iptables --flush
rm -rf /data/media/0/B7
rm -rf /data/data/com.pubg.krmobile/app_crashrecord
touch /data/data/com.pubg.krmobile/app_crashrecord
chmod 000 /data/data/com.pubg.krmobile/databases/*
sleep 10
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Updater.ini

iptables -I INPUT -p tcp -s astat.bugly.qcloud.com -j ACCEPT
iptables -I OUTPUT -p tcp -d astat.bugly.qcloud.com  -j ACCEPT
iptables -I INPUT -p tcp -s cloud.gsdk.proximabeta.com -j ACCEPT
iptables -I OUTPUT -p tcp -d cloud.gsdk.proximabeta.com  -j ACCEPT
iptables -I INPUT -p tcp -s down.anticheatexpert.com -j ACCEPT
iptables -I OUTPUT -p tcp -d down.anticheatexpert.com  -j ACCEPT
iptables -I INPUT -p tcp -s astat.bugly.qcloud.com -j ACCEPT
iptables -I OUTPUT -p tcp -d astat.bugly.qcloud.com  -j ACCEPT
iptables -I INPUT -p tcp -s cloud.gsdk.proximabeta.com -j ACCEPT
iptables -I OUTPUT -p tcp -d cloud.gsdk.proximabeta.com  -j ACCEPT
iptables -I INPUT -p tcp -s down.anticheatexpert.com -j ACCEPT
iptables -I OUTPUT -p tcp -d down.anticheatexpert.com  -j ACCEPT